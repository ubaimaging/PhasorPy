This is a library to performe phasor analysis with microscopy images.
#long description coming soon 